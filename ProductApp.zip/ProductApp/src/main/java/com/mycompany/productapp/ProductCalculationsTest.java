/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productapp;
/**
 *
 * @author 50324
 */
public class ProductCalculationsTest {

    public static void main(String[] args) {

        ProductCalculations calc =
                new ProductCalculations(3500);

        double expectedVat = 525;
        double actualVat = calc.GetVat();

        if(expectedVat == actualVat) {

            System.out.println(
                "GetVat_WithValidData_ReturnsCorrectValue PASSED"
            );
        }

        double expectedTotal = 4200;
        double actualTotal = calc.GetTotal();

        if(expectedTotal == actualTotal) {

            System.out.println(
                "GetTotal_WithValidData_ReturnsCorrectValue PASSED"
            );
        }
    }
}