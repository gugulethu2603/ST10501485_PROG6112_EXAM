/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productapp;

/**
 *
 * @author 50324
 */



import javax.swing.*;
import java.awt.*;
import java.io.*;

interface IProductCalculations {

    double GetVat();

    double GetCommission();

    double GetTotal();
}

class ProductCalculations implements IProductCalculations {

    private double price;

    public ProductCalculations(double price) {
        this.price = price;
    }

    @Override
    public double GetVat() {
        return price * 0.15;
    }

    @Override
    public double GetCommission() {
        return price * 0.05;
    }

    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}

public class ProductApp extends JFrame {

    JTextField txtCustomer;
    JTextField txtPrice;

    JComboBox<String> cmbProduct;

    JButton btnProcess;

    public ProductApp() {

        setTitle("Product App");

        setSize(500,300);

        setDefaultCloseOperation(EXIT_ON_CLOSE);

        setLayout(new GridLayout(4,2));

        JMenuBar bar = new JMenuBar();

        JMenu file = new JMenu("File");
        JMenu tools = new JMenu("Tools");

        JMenuItem exit = new JMenuItem("Exit");
        JMenuItem process = new JMenuItem("Process");
        JMenuItem clear = new JMenuItem("Clear");

        file.add(exit);

        tools.add(process);
        tools.add(clear);

        bar.add(file);
        bar.add(tools);

        setJMenuBar(bar);

        txtCustomer = new JTextField();

        txtPrice = new JTextField();

        cmbProduct = new JComboBox<>();

        cmbProduct.addItem("Cozy Nights Monarch");
        cmbProduct.addItem("Restonic Barbados");
        cmbProduct.addItem("Sealy Phuket");

        btnProcess = new JButton("PROCESS");

        add(new JLabel("Customer Name"));
        add(txtCustomer);

        add(new JLabel("Select Product"));
        add(cmbProduct);

        add(new JLabel("Enter Price"));
        add(txtPrice);

        add(new JLabel(""));
        add(btnProcess);

        btnProcess.addActionListener(e -> ProcessSale());

        process.addActionListener(e -> ProcessSale());

        clear.addActionListener(e -> {

            txtCustomer.setText("");

            txtPrice.setText("");

            cmbProduct.setSelectedIndex(0);
        });

        exit.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    private void ProcessSale() {

        String customer = txtCustomer.getText();

        String product =
                cmbProduct.getSelectedItem().toString();

        double price =
                Double.parseDouble(txtPrice.getText());

        ProductCalculations calc =
                new ProductCalculations(price);

        double vat = calc.GetVat();

        double commission =
                calc.GetCommission();

        double total =
                calc.GetTotal();

        String message =
                "Customer Name: " + customer
                + "\nProduct: " + product
                + "\nVAT: R " + vat
                + "\nCOMMISSION: R " + commission
                + "\nTOTAL: R " + total;

        JOptionPane.showMessageDialog(
                null,
                message
        );

        try {

            PrintWriter out =
                    new PrintWriter(
                            new FileWriter("data.txt")
                    );

            out.println("DATA LOG");
            out.println(
                    "***********");

            out.println("Customer Name: "
                    + customer);

            out.println("Product: "
                    + product);

            out.println("VAT: R "
                    + vat);

            out.println("COMMISSION: R "
                    + commission);

            out.println("TOTAL: R "
                    + total);

            out.println(
                    "***********");

            out.close();

        }
        catch(Exception ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Error Saving File"
            );
        }
    }

    public static void main(String[] args) {

        new ProductApp();
    }
}
