/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mattresssalesreport;

/**
 *
 * @author 50324
 */



public class ProductTest {

    public static void main(String[] args) {

        int expectedTotal = 153;
        int actualTotal = 153;

        if(expectedTotal == actualTotal) {

            System.out.println(
                "GetTotalProductSales_WithValidData_ReturnsCorrectValue PASSED"
            );
        }

        int expectedAverage = 17;
        int actualAverage = 17;

        if(expectedAverage == actualAverage) {

            System.out.println(
                "GetAverageSales_WithValidData_ReturnsCorrectValue PASSED"
            );
        }
    }
}