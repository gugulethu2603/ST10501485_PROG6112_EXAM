/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssalesreport;

/**
 *
 * @author 50324
 */

import java.util.Scanner;

interface IProduct {

    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}

class Product implements IProduct {

    String[] names = {
        "Cozy Nights Monarch",
        "Restonic Barbados",
        "Sealy Phuket"
    };

    int[][] sales;

    public Product(int[][] data) {
        sales = data;
    }

    @Override
    public int GetTotalProductsSold() {

        int total = 0;

        for (int i = 0; i < sales.length; i++) {

            for (int j = 0; j < sales[i].length; j++) {

                total = total + sales[i][j];
            }
        }

        return total;
    }

    @Override
    public double GetAverageProductSold() {

        return (double) GetTotalProductsSold() / 9;
    }

    @Override
    public String GetMostPopularProduct() {

        int biggest = 0;
        String popular = "";

        for (int i = 0; i < sales.length; i++) {

            int productTotal = 0;

            for (int j = 0; j < sales[i].length; j++) {

                productTotal = productTotal + sales[i][j];
            }

            if (productTotal > biggest) {

                biggest = productTotal;
                popular = names[i];
            }
        }

        return popular + "(" + biggest + ")";
    }
}

class PrintProduct {

    public void PrintTotalSales(Product p) {

        System.out.println(
                "TOTAL PRODUCT SALES: "
                + p.GetTotalProductsSold());
    }

    public void PrintAverageSales(Product p) {

        System.out.println(
                "AVERAGE PRODUCT SALES: "
                + Math.round(p.GetAverageProductSold()));
    }

    public void PrintPopularProduct(Product p) {

        System.out.println(
                "MOST POPULAR PRODUCT: "
                + p.GetMostPopularProduct());
    }
}

public class MattressSalesReport {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        String[] products = {
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        };

        int[][] sales = new int[3][3];

        for (int i = 0; i < products.length; i++) {

            for (int j = 0; j < 3; j++) {

                System.out.print(
                        "Enter number of sales for month "
                        + (j + 1)
                        + " for "
                        + products[i]
                        + " mattress: ");

                sales[i][j] = input.nextInt();
            }

            System.out.println();
        }

        Product product = new Product(sales);

        PrintProduct report = new PrintProduct();

        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println();

        System.out.println(
                "**************");

        report.PrintTotalSales(product);

        report.PrintAverageSales(product);

        report.PrintPopularProduct(product);
    }
}
